import Link from "next/link";
import Image from "next/image";

const TopMenu = () => {
  const menuItems = [
    { href: "/sell", icon: "/icons-header/icon-sale.png", label: "Продать" },
    { href: "/chats", icon: "/icons-header/icon-chats.png", label: "Чаты" },
  ];

  return (
    <ul className="flex flex-row gap-x-6 items-end">
      {menuItems.map(({ href, icon, label }) => (
        <li key={href} className="flex flex-col items-center gap-2.5 min-w-11">
          <Link
            href={href}
            className="flex flex-col items-center gap-2.5 group"
            aria-label={label}
          >
            <Image
              src={icon}
              alt=""
              width={24}
              height={24}
              className="w-6 h-6 object-contain transition group-hover:opacity-80"
            />
            <span className="text-sm text-[#475569] group-hover:text-[#4F46E5] transition">
              {label}
            </span>
          </Link>
        </li>
      ))}
    </ul>
  );
};

export default TopMenu;

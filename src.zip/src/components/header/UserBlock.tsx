import TopMenu from "./TopMenu";
import Profile from "./Profile";

const UserBlock = () => {
  return (
    <div className="flex items-center gap-6">
      <TopMenu />
      <Profile />
    </div>
  );
};

export default UserBlock;

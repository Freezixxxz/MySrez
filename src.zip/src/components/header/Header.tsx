import UserBlock from "./UserBlock";
import LogoBlock from "./LogoBlock";
import SearchBlock from "./SearchBlock";

const Header = () => {
  return (
    <header className="sticky top-4 z-50 w-full max-w-7xl mx-auto px-4 md:px-8 bg-white/80 backdrop-blur-md rounded-2xl border border-[#E2E8F0] shadow-(--shadow-default) flex items-center justify-between gap-4 py-3">
      {/* Левая часть — фиксированная ширина по содержимому */}
      <div className="shrink-0">
        <LogoBlock />
      </div>

      {/* Поиск — занимает всё оставшееся пространство */}
      <div className="flex-1">
        <SearchBlock />
      </div>

      {/* Правая часть — фиксированная ширина по содержимому */}
      <div className="shrink-0">
        <UserBlock />
      </div>
    </header>
  );
};

export default Header;

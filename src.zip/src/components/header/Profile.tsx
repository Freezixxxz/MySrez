// components/header/Profile.tsx
import Image from "next/image";
import Link from "next/link";
import RoleToggle from "./RoleToggle";

const Profile = () => {
  return (
    <div className="flex items-center gap-4">
      <RoleToggle />

      <div className="flex items-center gap-3 pl-4 border-l border-[#E2E8F0]">
        <Image
          src="/icons-header/icon-profile.png"
          alt="Профиль"
          width={42}
          height={42}
          className="rounded-2xl"
        />
        <div>
          <Link
            href="/profile"
            className="font-medium text-[#0F172A] hover:text-[#4F46E5] transition"
          >
            Ярослав
          </Link>
          <p className="text-xs text-[#64748B]">ID 48291</p>
        </div>
      </div>
    </div>
  );
};

export default Profile;

// components/SlideOne.tsx
import Slide from "./Slide";

const SlideOne = () => {
  return <Slide src="/images/SlideOne.png" alt="Слайд один" priority />;
};

export default SlideOne;

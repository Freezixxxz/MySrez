// components/Slide.tsx
import Image from "next/image";

interface SlideProps {
  src: string;
  alt: string;
  priority?: boolean;
}

const Slide = ({ src, alt, priority = false }: SlideProps) => {
  return (
    <div className="relative w-full h-[200px] md:h-[320px] lg:h-[420px] overflow-hidden rounded-3xl shadow-xl">
      <Image
        src={src}
        alt={alt}
        fill
        className="object-cover"
        priority={priority}
      />
    </div>
  );
};

export default Slide;

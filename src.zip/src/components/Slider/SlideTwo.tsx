// components/SlideTwo.tsx
import Slide from "./Slide";

const SlideTwo = () => {
  return <Slide src="/images/slide-two.png" alt="Слайд 2" />;
};

export default SlideTwo;

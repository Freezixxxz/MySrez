import Image from "next/image";
import Slider from "../components/Slider/Slider";
import Blitz from "../components/Blitz";

export default function Home() {
  return (
    <div className="space-y-20">
      <Slider />
      <Blitz />
    </div>
  );
}

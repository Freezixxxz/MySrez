// app/profile/page.tsx
"use client";
import { useState } from "react";
import Image from "next/image";
import ProductCard from "../../components/ProductCard";

const mockPurchases = [
  {
    id: 101,
    title: "Аккаунт WoT Blitz 15к боёв",
    price: 1250,
    date: "12 марта",
  },
  { id: 102, title: "5000 голды", price: 420, date: "10 марта" },
];

const mockSales = [
  {
    id: 201,
    title: "Аккаунт с 3 танками Т10",
    price: 890,
    date: "11 марта",
    status: "Продано",
  },
  {
    id: 202,
    title: "Буст до 10 уровня",
    price: 1450,
    date: "8 марта",
    status: "В процессе",
  },
];

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<
    "purchases" | "sales" | "chats" | "balance"
  >("purchases");
  const [role] = useState<"buyer" | "seller">("buyer"); // можно связать с RoleToggle позже

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-2">Личный кабинет</h1>
        <p className="text-[#64748B]">Ярослав • Баланс: 2 340 ₽</p>
      </div>

      {/* Табы */}
      <div className="flex gap-2 mb-8 border-b border-[#E2E8F0] pb-1 overflow-x-auto">
        {[
          { id: "purchases", label: "Мои покупки" },
          { id: "sales", label: "Мои продажи" },
          { id: "chats", label: "Чаты" },
          { id: "balance", label: "Баланс и вывод" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-8 py-3 rounded-3xl font-medium transition-all whitespace-nowrap ${
              activeTab === tab.id
                ? "bg-[#4F46E5] text-white shadow-sm"
                : "hover:bg-white/70"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Содержимое табов */}
      {activeTab === "purchases" && (
        <div className="space-y-8">
          <h2 className="text-2xl font-semibold">История покупок</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {mockPurchases.map((item) => (
              <div key={item.id} className="glass p-6 rounded-3xl">
                <p className="font-medium">{item.title}</p>
                <p className="text-2xl font-bold mt-2">{item.price} ₽</p>
                <p className="text-sm text-[#64748B] mt-4">
                  Куплено {item.date}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "sales" && (
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Мои товары на продаже</h2>
            <a
              href="/sell"
              className="text-[#4F46E5] font-medium hover:underline"
            >
              + Выставить новый товар
            </a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {mockSales.map((item) => (
              <div key={item.id} className="glass p-6 rounded-3xl">
                <p className="font-medium">{item.title}</p>
                <p className="text-2xl font-bold mt-2">{item.price} ₽</p>
                <div className="mt-4 flex justify-between text-sm">
                  <span className="text-[#64748B]">{item.date}</span>
                  <span className="font-medium text-emerald-600">
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "chats" && (
        <div className="glass rounded-3xl p-8">
          <h2 className="text-2xl font-semibold mb-6">Чаты с покупателями</h2>
          <p className="text-center text-[#64748B] py-12">
            Здесь будут появляться чаты (страница /chats скоро)
          </p>
        </div>
      )}

      {activeTab === "balance" && (
        <div className="glass rounded-3xl p-10 text-center">
          <p className="text-6xl font-bold mb-4">2 340 ₽</p>
          <button className="bg-[#4F46E5] text-white px-10 py-4 rounded-3xl text-lg font-medium">
            Вывести на карту
          </button>
        </div>
      )}
    </div>
  );
}

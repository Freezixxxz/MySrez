// app/sell/page.tsx
"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

export default function SellPage() {
  const router = useRouter();
  const [role] = useState<"seller">("seller"); // можно потом связать с RoleToggle

  const [form, setForm] = useState({
    title: "",
    description: "",
    basePrice: "",
    discountPercent: "0",
    category: "WoTBitz",
  });

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setImagePreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess(true);
      setTimeout(() => {
        router.push("/profile"); // после успеха уходим в профиль
      }, 2200);
    }, 1200);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-[#0F172A]">
          {role === "seller" ? "Выставить товар на продажу" : "Продать"}
        </h1>
        <p className="text-[#64748B] mt-2">
          Заполните данные — товар появится в каталоге
        </p>
      </div>

      <form onSubmit={handleSubmit} className="glass rounded-3xl p-8 md:p-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Левая колонка — фото */}
          <div>
            <p className="font-medium mb-3">Фото товара (основное)</p>
            <label className="block border-2 border-dashed border-[#E2E8F0] hover:border-[#4F46E5] rounded-3xl h-[380px] flex flex-col items-center justify-center cursor-pointer transition overflow-hidden">
              {imagePreview ? (
                <Image
                  src={imagePreview}
                  alt="preview"
                  width={500}
                  height={380}
                  className="object-cover w-full h-full"
                />
              ) : (
                <>
                  <div className="w-16 h-16 bg-[#EEF2F9] rounded-2xl flex items-center justify-center mb-4">
                    📸
                  </div>
                  <p className="text-[#475569]">Нажмите или перетащите фото</p>
                  <p className="text-xs text-[#94A3B8] mt-1">
                    JPG, PNG до 5 МБ
                  </p>
                </>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>
          </div>

          {/* Правая колонка — форма */}
          <div className="space-y-8">
            <div>
              <label className="block text-sm font-medium mb-2">
                Название товара
              </label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Аккаунт WoT Blitz с Т10 танками"
                className="w-full rounded-3xl border border-[#E2E8F0] px-6 py-4 focus:outline-none focus:border-[#4F46E5]"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Категория
              </label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full rounded-3xl border border-[#E2E8F0] px-6 py-4 focus:outline-none focus:border-[#4F46E5]"
              >
                <option value="WoTBitz">Аккаунты WoT Blitz</option>
                <option value="currency">Голда / Валюта</option>
                <option value="Services">Буст / Услуги</option>
                <option value="another">Читы / Другое</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Цена, ₽
                </label>
                <input
                  type="number"
                  value={form.basePrice}
                  onChange={(e) =>
                    setForm({ ...form, basePrice: e.target.value })
                  }
                  placeholder="1250"
                  className="w-full rounded-3xl border border-[#E2E8F0] px-6 py-4 focus:outline-none focus:border-[#4F46E5]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Скидка, %
                </label>
                <input
                  type="number"
                  value={form.discountPercent}
                  onChange={(e) =>
                    setForm({ ...form, discountPercent: e.target.value })
                  }
                  placeholder="0"
                  min="0"
                  max="90"
                  className="w-full rounded-3xl border border-[#E2E8F0] px-6 py-4 focus:outline-none focus:border-[#4F46E5]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Описание</label>
              <textarea
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                rows={5}
                placeholder="Полностью рабочий аккаунт. 15000 боёв, 3 премиум танка..."
                className="w-full rounded-3xl border border-[#E2E8F0] px-6 py-4 focus:outline-none focus:border-[#4F46E5] resize-none"
                required
              />
            </div>
          </div>
        </div>

        {/* Кнопка */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="mt-10 w-full h-16 bg-[#4F46E5] hover:bg-[#4338ca] disabled:bg-[#94A3B8] text-white text-xl font-medium rounded-3xl transition flex items-center justify-center gap-3"
        >
          {isSubmitting ? "Выставляем товар..." : "Выставить товар на продажу"}
        </button>
      </form>

      {/* Успешное уведомление */}
      {success && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="glass max-w-md w-full rounded-3xl p-10 text-center">
            <div className="text-7xl mb-6">🎉</div>
            <h2 className="text-3xl font-bold">Товар успешно выставлен!</h2>
            <p className="text-[#64748B] mt-3">
              Покупатели уже могут его видеть
            </p>
            <button
              onClick={() => router.push("/profile")}
              className="mt-8 bg-[#4F46E5] text-white px-10 py-4 rounded-3xl"
            >
              Перейти в профиль
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

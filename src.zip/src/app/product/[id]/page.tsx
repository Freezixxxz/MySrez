// app/product/[id]/page.tsx
"use client";

import Image from "next/image";
import { useState } from "react";
import { useParams } from "next/navigation";
import database from "../../../data/database.json";
import iconHeart from "@/public/icons-header/icon-heart.svg";

export default function ProductPage() {
  const params = useParams();
  const productId = parseInt(params.id as string);
  const product = database.products.find((p) => p.id === productId);

  if (!product) {
    return (
      <div className="text-center py-20">
        <h1 className="text-4xl font-bold text-red-500">Товар не найден 😢</h1>
        <p className="mt-4 text-[#64748B]">Проверьте ID товара</p>
      </div>
    );
  }

  const finalPrice =
    product.discountPercent > 0
      ? Math.round(product.basePrice * (1 - product.discountPercent / 100))
      : product.basePrice;

  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      from: "seller",
      text: "Здравствуйте! Аккаунт в отличном состоянии, все логины/пароли рабочие.",
    },
    { from: "buyer", text: "А можно скрины с боёв?" },
  ]);
  const [newMessage, setNewMessage] = useState("");

  const sendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, { from: "buyer", text: newMessage.trim() }]);
      setNewMessage("");
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Фото */}
        <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-xl bg-white">
          <Image
            src={product.img}
            alt={product.title}
            fill
            className="object-cover"
            sizes="(max-width: 1024px) 100vw, 50vw"
            priority
          />
          <button className="absolute top-4 right-4 glass w-11 h-11 rounded-2xl flex items-center justify-center hover:scale-110 transition">
            <Image src={iconHeart} alt="В избранное" width={24} height={24} />
          </button>
        </div>

        {/* Информация */}
        <div className="flex flex-col">
          <h1 className="text-4xl font-bold leading-tight text-[#0F172A]">
            {product.title}
          </h1>
          <p className="text-[#64748B]">
            ID {product.id} • World of Tanks Blitz
          </p>

          <div className="mt-8 text-5xl font-bold text-[#0F172A]">
            {finalPrice} <span className="text-2xl">₽</span>
            {product.discountPercent > 0 && (
              <span className="block text-xl line-through text-[#94A3B8] mt-1">
                {product.basePrice} ₽
              </span>
            )}
          </div>

          {/* Продавец */}
          <div className="glass mt-8 p-6 rounded-3xl flex gap-4 items-center">
            <div className="w-14 h-14 bg-[#4F46E5] rounded-2xl flex items-center justify-center text-white text-3xl font-bold">
              А
            </div>
            <div>
              <p className="font-semibold">Алексей • Продавец</p>
              <p className="text-sm text-[#64748B]">98 продаж • 4.97 ★</p>
            </div>
          </div>

          {/* Кнопки */}
          <div className="mt-auto pt-10 flex flex-col gap-4">
            <button
              onClick={() => alert("✅ Добавлено в корзину!")}
              className="h-14 bg-[#4F46E5] text-white rounded-3xl font-medium text-lg hover:bg-[#4338ca] transition"
            >
              В корзину
            </button>
            <button
              onClick={() => setIsChatOpen(true)}
              className="h-14 border-2 border-[#4F46E5] text-[#4F46E5] rounded-3xl font-medium hover:bg-[#4F46E5] hover:text-white transition"
            >
              Написать продавцу
            </button>
          </div>
        </div>
      </div>

      {/* Мини-чат */}
      {isChatOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="glass w-full max-w-lg rounded-3xl overflow-hidden">
            <div className="p-5 border-b flex justify-between bg-white/80">
              <p className="font-semibold">Чат с Алексеем</p>
              <button onClick={() => setIsChatOpen(false)} className="text-xl">
                ✕
              </button>
            </div>

            <div className="h-96 p-5 overflow-y-auto space-y-4 bg-[#F8FAFC]">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[80%] p-4 rounded-3xl ${
                    m.from === "buyer"
                      ? "ml-auto bg-[#4F46E5] text-white"
                      : "bg-white"
                  }`}
                >
                  {m.text}
                </div>
              ))}
            </div>

            <div className="p-4 border-t flex gap-3 bg-white">
              <input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                placeholder="Напишите сообщение..."
                className="flex-1 border rounded-3xl px-5 py-3 focus:outline-none focus:border-[#4F46E5]"
              />
              <button
                onClick={sendMessage}
                className="bg-[#4F46E5] text-white px-8 rounded-3xl font-medium"
              >
                →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
